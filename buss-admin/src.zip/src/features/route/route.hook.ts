import { useMutation, useQueryClient } from "@tanstack/react-query";
import { route } from "./route.methods";

export const useUpdateRoute = function () {
  const queryClient = useQueryClient();
  const { mutate, isPending } = useMutation({
    mutationFn: route.updateRoute,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["route"] });
    },
  });
  return { mutate, isPending };
};
